# 기사 패키지: {주제}

> 작성일: YYYY-MM-DD · 버전: v1 · 상태: 초안(발행 전 사람 승인 필요)
> `<!-- BEGIN:xxx -->` / `<!-- END:xxx -->` 표식은 `scripts/check_article.py`가 읽는다. 지우지 말 것.

## 1. 키워드
<!-- BEGIN:keywords -->
핵심: {핵심 키워드}
보조: {보조1}, {보조2}, {보조3}
<!-- END:keywords -->

## 2. 제목안 (★ = 추천)
<!-- BEGIN:titles -->
1. ★ {제목안 1}
2. {제목안 2}
3. {제목안 3}
<!-- END:titles -->
추천 이유: {1줄}

## 3. 메타설명 (구글판, 80~120자)
<!-- BEGIN:meta_description -->
{메타설명}
<!-- END:meta_description -->

## 4. 슬러그
<!-- BEGIN:slug -->
{english-keyword-slug}
<!-- END:slug -->

## 5. 본문 — 구글/워드프레스판
<!-- BEGIN:body_google -->
# {추천 제목}

{answer-first 도입 2~3문장. 첫 100자 안에 핵심 키워드.}

**핵심 요약**
- {요약1}
- {요약2}
- {요약3}

## {질문형 H2}?
{첫 문장 = 직접 답.} {설명·근거 [근거#1]}

![{인포그래픽 alt}](visuals/{id}.webp)

...

## 자주 묻는 질문
(FAQ 섹션 내용과 동일)

## 마무리
{요약 + 다음 행동}

*작성: {저자명·직함} · 최종 수정: YYYY-MM-DD*
<!-- END:body_google -->

## 6. FAQ
<!-- BEGIN:faq -->
Q. {질문1}
A. {결론 문장. 보충 1~3문장.}

Q. {질문2}
A. {...}
<!-- END:faq -->

## 7. JSON-LD
<!-- BEGIN:jsonld -->
```json
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BlogPosting",
      "headline": "",
      "description": "",
      "author": {"@type": "Person", "name": ""},
      "datePublished": "",
      "dateModified": "",
      "image": "",
      "mainEntityOfPage": ""
    }
  ]
}
```
<!-- END:jsonld -->

## 8. 태그 (워드프레스·티스토리, 5~10개)
<!-- BEGIN:tags -->
#{태그1} #{태그2} ...
<!-- END:tags -->

## 9. 링크 제안
- 내부: {관련 글 주제 2~5개}
- 외부(1차 출처): {기관명 — URL}

## 10. 이미지 (5단계: 스티커로 꾸민 썸네일·인포그래픽 — `visual-plan.json` → `visuals/`)
<!-- BEGIN:visuals -->
| 위치 | 파일 | 종류 | 사용 스티커 | alt |
|---|---|---|---|---|
| 대표 이미지 ({정사각형 1080×1080 / 가로형 1280×720}) | visuals/thumbnail.webp | thumbnail | {캐릭터, 말풍선, 소품} | {alt} |
| {H2 제목} 아래 | visuals/{id}.webp | {steps·compare·checklist·keypoint·stats} | {캐릭터, 소품} | {alt} |
<!-- END:visuals -->
- 본문 이미지·인포그래픽은 모두 가로형 1280×720. 썸네일만 0단계에서 사람이 고른 비율.
- 게시 파일: `python3 scripts/make_post.py article-package.md` → `post-google.html`(인라인 스타일, 저장소 이미지 주소), `titles-hashtags.md`(추천 제목·해시태그, 따로 전달), `preview.html`(복사 버튼)
- 본문의 `[근거#n]`은 게시 HTML에서 자동으로 빠지고 아래 11번 참고자료 목록이 붙는다. 11번은 "1. 출처명, 발표일, URL" 형식으로 채운다.

## 11. 참고자료 (발행본 하단 표기용)
1. {출처명, 발표일, URL}

## 12. 자체 점검 (AEO 6문항)
1. 첫 단락만으로 답이 되는가: 예/아니오 — {근거}
...

## 13. 사람이 채워야 할 것 / 확인 필요
- [경험 보강 필요] ...
- [확인 필요] ...
- 갱신 주기: {예: 제도 변경 시 / 6개월마다}
- 이미지 후보(작성자 메모): {인포그래픽이 어울리는 H2와 유형 — steps/compare/checklist/keypoint/stats}
