import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from PIL import Image
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from article_state import finalize_article
from image_assets import inventory, validate, digest


class SuppliedImages(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.d = Path(self.temp.name)
        sample = ROOT / 'tests/samples'
        self.package = self.d/'article-package.md'
        shutil.copy2(sample/'good-package.md', self.package)
        shutil.copytree(sample/'visuals', self.d/'visuals')
        review = self.d/'review-facts.md'
        review.write_text('테스트 픽스처 검토 기록', encoding='utf-8')
        ready = finalize_article(self.package, review)
        self.plan = {'article_sha256': ready['sha256'], 'thumbnail_format': 'landscape', 'images': [
            {'id': 'thumbnail', 'type': 'thumbnail', 'article_section': '__title__',
             'asset_id': 'user-1', 'alt': '사용자 제공 원두 보관 썸네일'},
            {'id': 'user-body', 'type': 'keypoint', 'article_section': ready['headings'][0],
             'asset_id': 'user-2', 'alt': '사용자가 정리한 원두 보관 요령'}]}
        self.sources = []
        # Small deterministic fixture pictures; no generated production images are used.
        for n, color in enumerate(['#437baf', '#aa7844'], 1):
            p = self.d/f'supplied-{n}.png'
            Image.new('RGB', (640, 360), color).save(p)
            self.sources.append(p)
        inventory(self.d, self.sources)
        self.assets = json.loads((self.d/'user-assets.json').read_text(encoding='utf-8'))

    def tearDown(self):
        self.temp.cleanup()

    def save(self):
        (self.d/'user-assets.json').write_text(json.dumps(self.assets), encoding='utf-8')

    def test_missing_inventory_and_pending_input_block(self):
        with self.assertRaisesRegex(ValueError, 'UNRESOLVED'):
            validate(self.d, self.plan, {})
        (self.d/'user-assets.json').unlink()
        with self.assertRaisesRegex(ValueError, 'USER_ASSETS_REQUIRED'):
            validate(self.d, self.plan, {})

    def test_reference_requires_reason_and_is_not_reuse(self):
        self.assets['assets'][0]['decision'] = 'reference'
        self.save()
        with self.assertRaisesRegex(ValueError, '사유'):
            validate(self.d, self.plan, {})

    def test_sticker_import_without_actual_use_is_blocked(self):
        self.assets['assets'][0].update(decision='sticker', sticker_ids=['custom-sticker'])
        self.save()
        with self.assertRaisesRegex(ValueError, 'USER_STICKER_UNUSED'):
            validate(self.d, self.plan, {'custom-sticker': {}})

    def test_changed_and_wrong_ratio_inputs_block(self):
        for a in self.assets['assets']:
            a['decision'] = 'reuse'
        self.save()
        Image.new('RGB', (100, 100)).save(self.sources[0])
        with self.assertRaisesRegex(ValueError, 'CHANGED'):
            validate(self.d, self.plan, {})
        self.assets['assets'][0]['sha256'] = digest(self.sources[0])
        self.save()
        with self.assertRaisesRegex(ValueError, 'RATIO'):
            validate(self.d, self.plan, {})

    def test_reuse_is_byte_identical_and_no_new_rendering(self):
        for a in self.assets['assets']:
            a['decision'] = 'reuse'
        self.save()
        (self.d/'visual-plan.json').write_text(json.dumps(self.plan), encoding='utf-8')
        out = self.d/'result'
        result = subprocess.run([sys.executable, str(ROOT/'scripts/make_visual.py'),
            str(self.d/'visual-plan.json'), '--package', str(self.package), '--out', str(out)],
            capture_output=True, text=True, encoding='utf-8', env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        report = json.loads((out/'visuals-report.json').read_text(encoding='utf-8'))
        self.assertEqual(report['summary']['FAIL'], 0)
        self.assertEqual(len(list(out.glob('*.html'))), 0)
        for source, iid in zip(self.sources, ['thumbnail', 'user-body']):
            self.assertEqual(digest(source), digest(out/(iid+'.png')))
            self.assertEqual(report['images'][iid]['source_kind'], 'user')


if __name__ == '__main__':
    unittest.main()
