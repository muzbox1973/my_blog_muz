"""Real Chromium check: sequential status updates, rotation, blocking, offline, reduced motion."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
import status


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--screenshot')
    args = parser.parse_args()
    result = {}
    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp)
        cli = [sys.executable, '-X', 'utf8', str(ROOT/'scripts/status.py'), '--dir', temp]
        subprocess.run(cli+['init', '--task', '스킬 검증 — 진행 화면 테스트'], check=True, capture_output=True)
        process = subprocess.Popen(cli+['serve'], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   text=True, encoding='utf-8')
        try:
            url = process.stdout.readline().strip()
            with sync_playwright() as pw:
                browser = pw.chromium.launch()
                page = browser.new_page(viewport={'width': 1360, 'height': 950})
                errors = []
                page.on('pageerror', lambda err: errors.append(str(err)))
                page.goto(url)
                page.wait_for_function("document.querySelector('#conn').classList.contains('live')")
                state = status.load(directory)
                for stage in ['1', '2']:
                    status.go_to(state, stage)
                status.save(directory, state)
                page.wait_for_function("document.querySelector('#phase-writing').classList.contains('active')")
                transform = lambda: page.locator('#phase-writing .indicator').evaluate('(el)=>getComputedStyle(el).transform')
                a = transform()
                page.wait_for_timeout(150)
                assert transform() != a, 'spinner does not move'
                canvas = page.locator('#office').evaluate('(el)=>el.toDataURL()')
                page.wait_for_timeout(350)
                assert page.locator('#office').evaluate('(el)=>el.toDataURL()') != canvas, 'office canvas does not animate'
                result['writing_spinner_and_canvas'] = 'pass'
                for stage in ['3', '4', '5']:
                    status.go_to(state, stage)
                status.save(directory, state)
                page.wait_for_function("document.querySelector('#phase-images').classList.contains('active')")
                assert 'done' in page.locator('#phase-writing').get_attribute('class')
                result['current_state_without_history_replay'] = 'pass'
                status.do_set(state, 'design', 'blocked', '테스트 오류 — 실제 생성은 수행하지 않음')
                status.save(directory, state)
                page.wait_for_function("document.querySelector('#phase-images').classList.contains('blocked')")
                assert page.locator('#phase-images .indicator').evaluate('(el)=>getComputedStyle(el).animationName') == 'none'
                result['blocked_stops_spinner'] = 'pass'
                status.do_set(state, 'design', 'done', '테스트 확인 완료')
                status.go_to(state, '6')
                status.save(directory, state)
                page.wait_for_function("document.querySelector('#phase-finishing').classList.contains('active')")
                result['finishing_stage'] = 'pass'
                if args.screenshot:
                    page.screenshot(path=args.screenshot, full_page=True)
                reduced = browser.new_page(reduced_motion='reduce')
                reduced.goto(url)
                reduced.wait_for_function("document.querySelector('#phase-finishing').classList.contains('active')")
                assert reduced.locator('#phase-finishing .indicator').evaluate('(el)=>getComputedStyle(el).animationName') == 'none'
                result['reduced_motion'] = 'pass'
                subprocess.run(cli+['stop'], check=True, capture_output=True)
                process.wait(timeout=5)
                page.wait_for_function("document.querySelector('#conn').classList.contains('lost')", timeout=10000)
                assert 'blocked' in page.locator('#phase-finishing').get_attribute('class')
                result['connection_loss'] = 'pass'
                assert not errors, errors
                result['javascript_errors'] = errors
                browser.close()
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
            process.stdout.close()
            process.stderr.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
