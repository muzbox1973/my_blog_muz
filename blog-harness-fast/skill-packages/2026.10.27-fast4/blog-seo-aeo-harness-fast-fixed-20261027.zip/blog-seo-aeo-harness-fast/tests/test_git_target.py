"""Exercise actual git setup/push against an isolated local bare repository."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from repo_setup import sha


@unittest.skipUnless(shutil.which('git'), 'git is required')
class GitTarget(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.d = Path(self.temp.name)
        self.repo = self.d/'checkout'
        self.remote = self.d/'remote.git'
        subprocess.run(['git', 'init', '--bare', str(self.remote)], check=True, capture_output=True)
        subprocess.run(['git', 'init', '-b', 'main', str(self.repo)], check=True, capture_output=True)
        for key, value in [('user.name', 'Fixture'), ('user.email', 'fixture@example.invalid')]:
            self.git('config', key, value)
        self.git('remote', 'add', 'origin', str(self.remote))
        (self.repo/'unrelated.txt').write_text('outside harness')
        self.git('add', 'unrelated.txt')
        self.git('commit', '-m', 'fixture')

    def tearDown(self):
        self.temp.cleanup()

    def git(self, *args):
        return subprocess.run(['git', '-C', str(self.repo), *args], check=True, capture_output=True, text=True)

    def script(self, name, *args):
        return subprocess.run([sys.executable, '-X', 'utf8', str(ROOT/'scripts'/name),
            '--repo', str(self.repo), *args], capture_output=True, text=True, encoding='utf-8',
            env={**os.environ, 'PYTHONIOENCODING': 'utf-8'})

    def setup(self, **overrides):
        flags = {'--remote-url': str(self.remote), '--branch': 'main', '--base': 'chosen/nested',
                 '--post': 'test-post', '--owner': 'fixture', '--name': 'repo'}
        flags.update(overrides)
        return self.script('repo_setup.py', *[item for kv in flags.items() for item in kv])

    def test_missing_target_fields_block_setup(self):
        r = self.script('repo_setup.py')
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse((self.repo/'blog-harness-fast').exists())

    def test_windows_line_endings_are_not_user_edits(self):
        lf, crlf = self.d/'lf.py', self.d/'crlf.py'
        lf.write_bytes(b'print("fixture")\n')
        crlf.write_bytes(b'print("fixture")\r\n')
        self.assertEqual(sha(lf), sha(crlf))
        crlf.write_bytes(b'print("user edit")\r\n')
        self.assertNotEqual(sha(lf), sha(crlf))

    def test_wrong_remote_or_branch_blocks_before_writes(self):
        for fields in [{'--remote-url': 'https://example.invalid/wrong.git'}, {'--branch': 'wrong'}]:
            with self.subTest(fields=fields):
                self.assertNotEqual(self.setup(**fields).returncode, 0)
                self.assertFalse((self.repo/'chosen').exists())

    def test_selected_nested_path_and_no_push_is_incomplete(self):
        r = self.setup()
        self.assertEqual(r.returncode, 0, r.stderr)
        cfg = json.loads((self.repo/'chosen/nested/harness.json').read_text(encoding='utf-8'))
        self.assertTrue(cfg['target_confirmed'])
        self.assertEqual(cfg['branch'], 'main')
        r = self.script('repo_sync.py', '--base', 'chosen/nested', 'publish', '--post', 'test-post', '--no-push')
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse((self.repo/'chosen/nested/posts/test-post/assets-urls.json').exists())
        self.assertEqual((self.repo/'unrelated.txt').read_text(), 'outside harness')

    def test_push_success_to_test_remote_and_mismatched_target_blocks(self):
        self.assertEqual(self.setup().returncode, 0)
        r = self.script('repo_sync.py', '--base', 'chosen/nested', 'publish', '--post', 'test-post', '--no-verify')
        self.assertEqual(r.returncode, 0, r.stderr)
        remote_head = subprocess.check_output(['git', '--git-dir', str(self.remote), 'rev-parse', 'main'], text=True).strip()
        self.assertEqual(remote_head, self.git('rev-parse', 'HEAD').stdout.strip())
        cfgp = self.repo/'chosen/nested/harness.json'
        cfg = json.loads(cfgp.read_text(encoding='utf-8'))
        cfg['branch'] = 'other'
        cfgp.write_text(json.dumps(cfg), encoding='utf-8')
        r = self.script('repo_sync.py', '--base', 'chosen/nested', 'publish', '--post', 'test-post')
        self.assertNotEqual(r.returncode, 0)


if __name__ == '__main__':
    unittest.main()
