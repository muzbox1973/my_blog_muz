"""Regression checks for text-first visuals, real progress, and original SEO gates."""
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from article_state import article_context, finalize_article, require_ready
from check_article import check
from status import fresh, go_to, load, do_set


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = Path(self.tmp.name)
        shutil.copytree(ROOT / "tests/samples", self.d, dirs_exist_ok=True)
        self.package = self.d / "article-package.md"
        self.package.write_bytes((self.d / "good-package.md").read_bytes())
        self.review = self.d / "review-facts.md"
        self.review.write_text("테스트 전용 검토 결과: fixture 검토 완료", encoding="utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def cli(self, *args):
        return subprocess.run([sys.executable, str(ROOT / "scripts/status.py"), "--dir", str(self.d), *args],
                              capture_output=True, text=True, encoding="utf-8", env={**__import__('os').environ, "PYTHONIOENCODING":"utf-8"})

    def test_original_seo_aeo_gates(self):
        good = self.package.read_text(encoding="utf-8")
        self.assertFalse(check(good, base_dir=str(self.d)).failed)
        self.assertTrue(check(good, final=True, base_dir=str(self.d)).failed)
        bad = (self.d / "broken-package.md").read_text(encoding="utf-8")
        report = check(bad, base_dir=str(self.d))
        self.assertTrue(report.failed)
        self.assertGreaterEqual(sum(i["level"] == "FAIL" for i in report.items), 6)

    def test_requires_review_and_lint(self):
        self.review.write_text("", encoding="utf-8")
        with self.assertRaises(ValueError):
            finalize_article(self.package, self.review)
        self.review.write_text("검토 완료", encoding="utf-8")
        self.package.write_text("미완성 원고", encoding="utf-8")
        with self.assertRaises(ValueError):
            finalize_article(self.package, self.review)
        self.assertFalse((self.d / "article-ready.json").exists())

    def test_unfinished_or_changed_text_blocks_visuals(self):
        with self.assertRaisesRegex(ValueError, "ARTICLE_NOT_READY"):
            require_ready(self.package)
        finalize_article(self.package, self.review)
        original = self.package.read_text(encoding="utf-8")
        for old, new in [("# 원두 보관법 총정리", "# 최종 제목 변경"),
                         ("## 원두는 왜", "## 커피는 왜"),
                         ("볶은 원두는 산소", "볶은 원두는 공기"),
                         ("Q. 분쇄한 커피도", "Q. 분쇄 커피도")]:
            with self.subTest(old=old):
                self.package.write_text(original.replace(old, new), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "ARTICLE_CHANGED"):
                    require_ready(self.package)
        self.package.write_text(original, encoding="utf-8")
        self.assertEqual(require_ready(self.package)["sha256"], article_context(self.package)["sha256"])

    def test_image_insertion_does_not_invalidate_text(self):
        before = finalize_article(self.package, self.review)["sha256"]
        text = self.package.read_text(encoding="utf-8").replace("<!-- END:body_google -->", "![새 그림](visuals/new.webp)\n<!-- END:body_google -->")
        text = text.replace("https://example.com/images/coffee-bean-storage.jpg", "https://example.com/final.webp")
        self.package.write_text(text, encoding="utf-8")
        self.assertEqual(before, require_ready(self.package)["sha256"])

    def test_plan_must_reference_current_article_sections(self):
        marker = finalize_article(self.package, self.review)
        plan = {"article_sha256": marker["sha256"], "images": [
            {"id":"thumbnail", "type":"thumbnail", "article_section":"__title__"},
            {"id":"body", "type":"steps", "article_section":marker["headings"][0]}]}
        require_ready(self.package, plan)
        stale = copy.deepcopy(plan); stale["article_sha256"] = "old"
        with self.assertRaisesRegex(ValueError, "PLAN_STALE"):
            require_ready(self.package, stale)
        plan["images"][1]["article_section"] = "원고에 없는 H2"
        with self.assertRaisesRegex(ValueError, "ARTICLE_SECTION"):
            require_ready(self.package, plan)

    def test_renderer_does_not_output_before_text_is_ready(self):
        plan = self.d / "visual-plan.json"
        out = self.d / "blocked-render"
        r = subprocess.run([sys.executable, str(ROOT / "scripts/make_visual.py"), str(plan),
                            "--package", str(self.package), "--out", str(out)], capture_output=True)
        self.assertNotEqual(r.returncode, 0)
        self.assertIn(b"ARTICLE_NOT_READY", r.stderr)
        self.assertFalse(out.exists())

    def test_real_sequential_stages_and_new_run(self):
        self.assertEqual(self.cli("init", "--task", "테스트").returncode, 0)
        first_run = load(self.d)["run_id"]
        self.assertNotEqual(self.cli("go", "5").returncode, 0)
        self.assertEqual(load(self.d)["stage"], "0")
        for stage in ["1", "2", "3", "4"]:
            self.assertEqual(self.cli("go", stage).returncode, 0)
            self.assertEqual(load(self.d)["agents"]["design"]["state"], "idle")
        self.assertNotEqual(self.cli("set", "design", "working").returncode, 0)
        self.assertEqual(self.cli("article-ready", "--package", str(self.package), "--review", str(self.review)).returncode, 0)
        for stage, who in [("5", "design"), ("6", "lead")]:
            if stage == "6":
                self.assertNotEqual(self.cli("go", stage).returncode, 0)
                self.assertEqual(self.cli("set", "design", "done", "실제 결과 확인 완료").returncode, 0)
            self.assertEqual(self.cli("go", stage).returncode, 0)
            self.assertEqual(load(self.d)["agents"][who]["state"], "working")
        self.assertEqual(self.cli("go", "B").returncode, 0)
        self.assertFalse(load(self.d)["finished"])
        self.assertNotEqual(self.cli("go", "done").returncode, 0)
        # A fixture simulates separately verified publishing; no live repository is changed.
        (self.d / "assets-urls.json").write_text(json.dumps({"pushed": True,
            "files": {"visuals/thumbnail.png": "https://example.com/fixture.png"},
            "check": {"ok": 1, "fail": [], "unverified": 0}}), encoding="utf-8")
        self.assertEqual(self.cli("go", "done").returncode, 0)
        self.assertTrue(load(self.d)["finished"])
        self.assertEqual(self.cli("init", "--task", "새 작업").returncode, 0)
        self.assertNotEqual(load(self.d)["run_id"], first_run)
        self.assertFalse((self.d / "article-ready.json").exists())

    def test_no_fabricated_skipped_completion(self):
        state = fresh("테스트")
        with self.assertRaises(ValueError):
            go_to(state, "6")
        self.assertEqual(state["stage"], "0")
        self.assertTrue(all(a["state"] == "idle" for a in state["agents"].values()))

    def test_failed_images_do_not_become_finished(self):
        state = fresh("이미지 실패")
        for stage in ["1", "2", "3", "4", "5"]:
            go_to(state, stage)
        do_set(state, "design", "blocked", "렌더 실패")
        with self.assertRaises(ValueError):
            go_to(state, "6")
        self.assertEqual(state["stage"], "5")
        self.assertEqual(state["agents"]["design"]["state"], "blocked")

    def test_loopback_server_and_stop(self):
        self.cli("init", "--task", "화면 테스트")
        process = subprocess.Popen([sys.executable, str(ROOT / "scripts/status.py"), "--dir", str(self.d), "serve"],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            url = process.stdout.readline().strip()
            self.assertTrue(url.startswith("http://127.0.0.1:"))
            base = url.rsplit("/", 1)[0]
            with urlopen(url, timeout=3) as r:
                self.assertEqual(r.status, 200)
                self.assertEqual(r.headers["Cache-Control"], "no-store")
            self.cli("go", "1")
            with urlopen(base + "/status.json", timeout=3) as r:
                self.assertEqual(json.load(r)["stage"], "1")
            for path in ["/article-package.md", "/.progress-server.json", "/../article-package.md"]:
                with self.assertRaises(HTTPError) as raised:
                    urlopen(base + path, timeout=3)
                self.assertEqual(raised.exception.code, 404)
            with self.assertRaises(HTTPError) as raised:
                urlopen(Request(base + "/stop", method="POST"), timeout=3)
            self.assertEqual(raised.exception.code, 403)
            self.assertEqual(self.cli("stop").returncode, 0)
            process.wait(timeout=5)
            self.assertFalse((self.d / ".progress-server.json").exists())
        finally:
            if process.poll() is None:
                process.terminate(); process.wait(timeout=5)
            process.stdout.close(); process.stderr.close()


if __name__ == "__main__":
    unittest.main()
