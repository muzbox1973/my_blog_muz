# git 저장소 연동 가이드

하네스는 사용자가 지정한 git 저장소의 **하위 폴더**(기본 `blog-harness-fast/`)를 작업장으로 쓴다.
- 스크립트: `blog-harness-fast/scripts/`에 저장하고 **여기 있는 사본을 불러와 실행**한다 (사용자가 고친 스크립트도 그대로 쓰인다).
- 스티커: `blog-harness-fast/assets/stickers/` (기본 50종 + 사용자 추가)
- 글: `blog-harness-fast/posts/<YYYYMMDD-영문슬러그>/` (패키지, `visuals/` 이미지, 게시용 HTML, 제목·해시태그)
- 본문 HTML의 이미지는 이 저장소에 올린 파일을 **커밋 고정 주소**로 불러온다.

---

## 1. 저장소 묻기
- 시작 질문에서 항상 묻는다: `owner/repo` 또는 저장소 주소, 또는 이미 클론해 둔 컴퓨터 폴더.
- 저장소 목록 도구(`list_repos` 등)가 있으면 최근 저장소 2~3개를 선택지로 보여 준다.
- 안내 한 줄: "블로그에서 이미지를 불러오려면 **공개(public) 저장소**여야 해요. 비공개면 이미지가 안 보여요."
- 저장소 URL·브랜치·하위 경로를 모두 사용자에게 먼저 질문한다. 기본값은 선택지로 제안만 하며 응답 없이 확정하지 않는다. 로컬 파일만으로 완료하지 않는다.

## 2. 클론 확보 (먼저 되는 방법 하나)
1. **컴퓨터 폴더가 이미 클론이면** 그 폴더를 그대로 쓴다. 셸이 있으면 그 셸에서 git을 실행한다. 이 경우 POST 폴더가 곧 사람이 보는 폴더라 진행 화면 복사가 필요 없다.
2. **저장소 연결 도구가 있으면** (예: `add_repo(owner, repo, access="push")`) 연결한 뒤, 도구가 알려 주는 명령으로 클론한다.
3. **그 밖에는** 셸에서 `git clone https://github.com/<owner>/<repo>.git <작업공간>/<repo>`를 실행한다. 공개 저장소면 읽기는 된다. 푸시에는 인증이 필요하다 (4절).
- 토큰·비밀번호를 묻거나, 명령이나 파일에 적지 않는다. 인증은 사용자의 기존 설정이나 연결 도구에 맡긴다.

## 3. 작업 폴더 준비 — `repo_setup.py` (스킬에서 한 번 실행)
```
python3 <스킬>/scripts/repo_setup.py --repo <클론> --post 20261026-coffee-bean-storage
        --remote-url <확인 URL> --base <확인 경로> --branch <확인 브랜치> [--cdn jsdelivr|raw|custom] [--owner O --name R]
```
- 원격 주소에서 owner/repo를 읽고, 못 읽으면 `--owner --name`을 지정한다.
- 저장소에 없는 스크립트·스티커는 추가하고, 이전 설치본 그대로인 스크립트는 새 버전으로 갱신한다.
- **사용자가 고친 스크립트는 덮어쓰지 않는다** ("사용자 수정본 유지"로 출력). 스티커 PNG도 절대 덮어쓰지 않는다.
- 새 버전에서 없어진 스크립트는 손대지 않은 설치본일 때만 지운다.
- `harness.json`(저장소 설정), `VERSION`, `.gitignore`(미리보기·진행 화면 파일 제외), `README.md`를 만든다.
- 출력 마지막 줄 JSON의 `scripts`(=H)와 `post`(=POST) 경로를 이후 모든 명령에 쓴다.

## 4. 저장 — `repo_sync.py publish`
```
python3 H/repo_sync.py --repo <클론> --base <확인 경로> publish --post <글> -m "이미지: 원두 보관법"          # 이미지 올리기 + 주소 생성
python3 H/repo_sync.py --repo <클론> --base <확인 경로> publish --post <글> -m "게시 초안" --keep-urls      # 게시 파일 올리기 (주소 유지)
```
- `blog-harness-fast/` 아래만 `git add` → 커밋 → `origin <브랜치>`로 푸시한다. 거절되면 업로드 미완료로 보고한다. 자동 rebase·강제 푸시를 하지 않는다.
- git 사용자 정보가 없으면 `blog-seo-aeo-harness` 이름으로 커밋한다 (출력에 표시).
- **푸시 실패(종료코드 3)**: 커밋은 로컬에 남는다. 사람에게 다음 중 하나를 부탁한다.
  - 직접 푸시하기 (GitHub Desktop, `git push` 등)
  - 저장소 연결 도구에 푸시 권한 주기
  푸시가 끝나면 `repo_sync.py urls --post <글> --ref <브랜치 또는 커밋>`으로 주소를 다시 만든다.
- 푸시는 사용자가 지정한 저장소·브랜치에만 한다. 다른 저장소나 브랜치를 건드리지 않는다.

## 5. 이미지 주소
- `assets-urls.json`에 이미지별 주소를 적는다. `{ref}`는 **푸시한 커밋 SHA**라서 이후 파일이 바뀌어도 이미 붙여 넣은 글의 이미지는 그대로다.
  - `jsdelivr`(기본): `https://cdn.jsdelivr.net/gh/{owner}/{repo}@{ref}/{path}` — GitHub 공개 저장소, CDN 캐시
  - `raw`: `https://raw.githubusercontent.com/{owner}/{repo}/{ref}/{path}`
  - `custom`: `harness.json`의 `url_template` (GitLab 등)
- 만든 뒤 주소를 실제로 열어 본다.
  - 열림: 정상
  - **404 등 실패(종료코드 4)**: 비공개 저장소이거나 아직 반영 전이다. 사람에게 "저장소를 공개로 바꾸거나 이미지를 블로그에 직접 올려야 해요"라고 알린다.
  - 네트워크 차단으로 확인 불가: "확인 불가"로 남기고 진행한다. 미리보기 페이지가 사람 컴퓨터에서 주소를 다시 열어 보고 배지로 표시한다.

## 6. 사용자 스티커 추가
- 사람이 스티커 파일을 주거나 저장소 `blog-harness-fast/assets/stickers/inbox/`에 넣으면 다음을 실행한다.
  `python3 H/import_stickers.py <파일·폴더>`
  - 시트 한 장: `--sheet` (간격 넓음) 또는 `--boxes 좌표.json` (촘촘함)
- 규격은 제각각이어도 된다: PNG·JPG·WEBP, 어떤 크기·비율, 투명·단색·복잡한 배경.
- 가져온 뒤 `_preview.png`를 보고 `stickers.json`의 `use_when`·`avoid`(필요하면 `kind`·`has_text`·`text_inside`)를 채운다. 그다음 `publish --keep-urls`로 저장한다.

## 7. 하지 않는 것
- 사용자 저장소의 다른 폴더를 수정·삭제하지 않는다 (`blog-harness-fast/`만 다룸).
- 강제 푸시(`--force`)를 하지 않는다. 기록을 다시 쓰지 않는다.
- 비밀값을 저장소·로그·상태 화면에 남기지 않는다.
